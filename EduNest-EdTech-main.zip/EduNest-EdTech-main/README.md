<<<<<<< HEAD
# StudyNotion Edtech Project
=======
# StudyNotion-EdTech
Full Stack EdTech platform using MERN stack
>>>>>>> 751135cacc979c8ffdbb7c75b78e66c7dbfbc596

-Full-Stack MERN Web
-Tailwind Used

Usage
To run this web on your computer, follow these steps:

Clone the repository to your local machine.

git clone https://github.com/AyushR97j/StudyNotion-EdTech.git
Install the required packages. 

cd StudyNotion-EdTech
npm install
Start the development server:

npm run dev
Open the project in your browser at http://localhost:3000 to view your project.

-Build this project in Love Babbar's Dot Batch.

Contributing
Contributions are welcome! If you have any suggestions or find any issues, please feel free to open an issue or a pull request.
